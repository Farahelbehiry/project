
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import javax.swing.*;




public class LoginFrame extends JFrame {
    JPanel panel;
    JTextField player1Field;
    JTextField player2Field;
    JButton startButton;

    LoginFrame() {
        panel = new JPanel(new GridLayout(3, 2, 0, 10));
        player1Field = new JTextField();
        player2Field = new JTextField();
        startButton = new JButton("Start Game");

        panel.add(new JLabel("Player 1:"));
        panel.add(player1Field);
        panel.add(new JLabel("Player 2:"));
        panel.add(player2Field);
        panel.add(new JLabel(""));
        panel.add(startButton);

        panel.setBackground(Color.pink);
        this.setPreferredSize(new Dimension(400, 150));

        this.add(panel);
        this.setTitle("Login Window");
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);

        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String player1 = player1Field.getText();
                String player2 = player2Field.getText();

                if (!player1.isEmpty() && !player2.isEmpty()) {
                    // Save player names and scores, updating if they exist, adding if they don't
                    saveOrUpdatePlayer(player1);
                    saveOrUpdatePlayer(player2);

                    // Start the game
                    LoginFrame.this.dispose();
                    new GameFrame(player1, player2);
                } else {
                    JOptionPane.showMessageDialog(LoginFrame.this, "Please enter names for both players.");
                }
            }
        });
    }

    private void saveOrUpdatePlayer(String playerName) {
        try (Connection conn = SqlConnection.getConnection()) {
            // Check if the player exists
            String query = "SELECT score FROM players WHERE name = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(query)) {
                checkStmt.setString(1, playerName);
                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next()) {
                        // Player exists, explicitly set score to zero if required
                        String updateSql = "UPDATE players SET score = 0 WHERE name = ?";
                        try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                            updateStmt.setString(1, playerName);
                            updateStmt.executeUpdate();
                            System.out.println("Updated player " + playerName + " score to 0");
                        }
                    } else {
                        // Player does not exist, insert a new record with score 0
                        String insertSql = "INSERT INTO players (name, score) VALUES (?, 0)";
                        try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                            insertStmt.setString(1, playerName);
                            insertStmt.executeUpdate();
                            System.out.println("Inserted new player: " + playerName + " with score 0");
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving player name to the database.");
        }
    }
}




