import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;
import javax.swing.*;

public class GamePanel extends JPanel implements Runnable {

    static final int GAME_WIDTH = 1000;
    static final int GAME_HEIGHT = 560;
    static final Dimension SCREEN_SIZE = new Dimension(GAME_WIDTH, GAME_HEIGHT);
    static final int BALL_DIAMETER = 20;
    static final int PADDLE_WIDTH = 25;
    static final int PADDLE_HEIGHT = 100;
    Thread gameThread;
    Image image;
    Graphics graphics;
    Random room;
    Paddle paddle1;
    Paddle paddle2;
    Ball ball;
    Score score;
    String player1;
    String player2;
    int score1 = 0;
    int score2 = 0;


    GamePanel() {
        newPaddles();
        newBall();
        score = new Score(GAME_WIDTH, GAME_HEIGHT);
        this.setFocusable(true);
        this.addKeyListener(new KeyEvents());
        this.setPreferredSize(SCREEN_SIZE);

        gameThread = new Thread(this);
        gameThread.start();
    }

    GamePanel(String player1, String player2) {
        this.player1 = player1;
        this.player2 = player2;

        newPaddles();
        newBall();
        score = new Score(GAME_WIDTH, GAME_HEIGHT);
        this.setFocusable(true);
        this.addKeyListener(new KeyEvents());
        this.setPreferredSize(SCREEN_SIZE);

        gameThread = new Thread(this);
        gameThread.start();
    }

    public void newBall() {
        room = new Random();
        ball = new Ball((GAME_WIDTH / 2) - (BALL_DIAMETER / 2), room.nextInt(GAME_HEIGHT - BALL_DIAMETER), BALL_DIAMETER, BALL_DIAMETER);
    }

    public void newPaddles() {
        paddle1 = new Paddle(0, (GAME_HEIGHT / 2) - (PADDLE_HEIGHT / 2), PADDLE_WIDTH, PADDLE_HEIGHT, 1);
        paddle2 = new Paddle(GAME_WIDTH - PADDLE_WIDTH, (GAME_HEIGHT / 2) - (PADDLE_HEIGHT / 2), PADDLE_WIDTH, PADDLE_HEIGHT, 2);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        image = createImage(getWidth(), getHeight());
        graphics = image.getGraphics();
        draw(graphics);
        g.drawImage(image, 0, 0, this);
    }

    public void draw(Graphics g) {
        paddle1.draw(g);
        paddle2.draw(g);
        ball.draw(g);
        score.draw(g,player1,player2);
        Toolkit.getDefaultToolkit().sync(); // it helps with the animation

    }

    public void move() {
        paddle1.move();
        paddle2.move();
        ball.move();
    }

    public void checkCollision() {

        //bounce ball off top & bottom window edges

        if (ball.y <= 0 || ball.y + BALL_DIAMETER >= GAME_HEIGHT) {
            ball.setYDirection(-ball.yVelocity);
        }

        //bounce ball off paddles
        if (ball.intersects(paddle1)) {
            ball.xVelocity = Math.abs(ball.xVelocity);
            ball.xVelocity++;
            if (ball.yVelocity>0)
                ball.yVelocity++;
            else
                ball.yVelocity--;
            ball.setXDirection(ball.xVelocity);
            ball.setYDirection(ball.yVelocity);

        }
        if (ball.intersects(paddle2)) {
            ball.xVelocity = Math.abs(ball.xVelocity);
            ball.xVelocity++;
            if (ball.yVelocity>0)
                ball.yVelocity++;
            else
                ball.yVelocity--;
            ball.setXDirection(-ball.xVelocity);
            ball.setYDirection(ball.yVelocity);

        }

        //give a player 1 point and creates new paddles & ball
        if (ball.x <= 0) {
            score.player2++;
            score2 = score.player2;

            newPaddles();
            newBall();
            System.out.println("Player 2: " + score.player2);
            updateScore(player2,score2);


        }
        //iF THE BALL.X THE LEFT SIDE OF THE BALL PLUS THE DIAMETER(GIVES UD THE RIGHT SIDE ) IS GREATER THAN THE GAME WIDTH

        if (ball.x +BALL_DIAMETER >= GAME_WIDTH ) {
            score.player1++;
            score1 = score.player1;

            newPaddles();
            newBall();
            System.out.println("Player 1: " + score.player1);
            updateScore(player1, score1);
        }


        //paddle boundries

        if(paddle1.y<=0)
            paddle1.y=0;
        if(paddle1.y>=(GAME_HEIGHT-PADDLE_HEIGHT))
            paddle1.y=GAME_HEIGHT-PADDLE_HEIGHT;
        if(paddle2.y<=0)
            paddle2.y=0;
        if(paddle2.y>=(GAME_HEIGHT-PADDLE_HEIGHT))
            paddle2.y=GAME_HEIGHT-PADDLE_HEIGHT;
    }


    private void updateScore(String player, int score) {
        try {
            Connection conn = SqlConnection.getConnection();
            String sql = "UPDATE players SET score = ? WHERE name = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, score);
            stmt.setString(2, player);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void run() {
        while (true) {
            long startTime = System.nanoTime(); // Start time for the current frame

            move(); // Update game objects
            checkCollision(); // Check and handle collisions
            repaint(); // Redraw the screen

            // Calculate how long the frame took and sleep for the remaining time to maintain 60 FPS
            long frameTime = System.nanoTime() - startTime;
            long sleepTime = (1000000000 / 70) - frameTime; // 70 FPS

            if (sleepTime > 0) {
                try {
                    Thread.sleep(sleepTime / 1000000); // Convert to milliseconds
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public class KeyEvents extends KeyAdapter {
        public void keyPressed(KeyEvent e) {
            paddle1.keyPressed(e);
            paddle2.keyPressed(e);
        }

        public void keyReleased(KeyEvent e) {
            paddle1.keyReleased(e);
            paddle2.keyReleased(e);
        }
    }
}

