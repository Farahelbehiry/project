
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
public class GameFrame extends JFrame{

   GamePanel gamePanel;

    GameFrame(String player1, String player2) {
        gamePanel = new GamePanel(player1, player2);
        this.add(gamePanel);
        this.setTitle("Pong Game");
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setBackground(Color.black);
    }
}
